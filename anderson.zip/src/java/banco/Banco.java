package banco;

import java.sql.*;
public class Banco {
	private String cod_mer;
        private String tip_mer;
	private String nom_mer;
	private String qtd_mer;
        private String prc_mer;
        //private String CV_mer;


    public Banco() {
    }
        public void setCod_mer(String cod_mer){
 		this.cod_mer = cod_mer;
 	}
 	public void setTip_mer(String tip_mer){
 		this.tip_mer = tip_mer;
 	}
 	public void setNom_mer(String nom_mer ){
 		this.nom_mer = nom_mer;
 	}
 	public void setQtd_mer(String Qtd_mer){
 		this.qtd_mer = Qtd_mer;
 	}
        public void setPrc_mer(String prc_mer){
 		this.prc_mer = prc_mer;
 	}

    public String getCod_mer(){
 		return cod_mer;
 	}
    public String getTip_mer(){
 		return tip_mer;
 	}
 	public String getNom_mer(){
 		return nom_mer;
 	}
 	public String getQtd_mer(){
 		return qtd_mer;
        }
        public String getPrc_mer(){
 		return prc_mer;
        }
    
 	public boolean incluir() {
        try {
            // Carregar Driver do MySQL
            Class.forName("com.mysql.jdbc.Driver");
            //Fazer a conex�o
            //Verifique se o usu�rio root e a senha root s�o iguais na m�quina de teste
            //caso contr�rio, altere na linha abaixo.
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/TESTE_ANDERSON", "root", "Als301295");
 			//Criar o fluxo para mandar comando sql o banco
            Statement stmt = con.createStatement();

            String sql = "insert into TESTE_ANDERSON (cod_mer, tip_mer, nom_mer, qtd_mer, prc_mer) VALUES (" +
                    "'"+ getCod_mer()+"',"+
                    "'"+ getTip_mer()+"',"+
                    "'"+ getNom_mer()+"',"+
                    "'"+ getQtd_mer()+"',"+
                    "'"+ getPrc_mer()+"')";

            // Executa o comando SQL
            stmt.executeUpdate(sql);
			//Fecha a conex�o
	        con.close();
            //Fecha o fluxo
            stmt.close();

        } catch (Exception ex) {
            return(false);
        }
        return(true);
    }
 	
    public boolean banco(int id){
    	 try {
            // Carregar Driver do MySQL
            Class.forName("com.mysql.jdbc.Driver");
            //Fazer a conex�o
            //Verifique se o usu�rio root e a senha root s�o iguais na m�quina de teste
            //caso contr�rio, altere na linha abaixo.
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/TESTE_ANDERSON", "root", "Als301295");
 			//Criar o fluxo para mandar comando sql o banco
            Statement stmt = con.createStatement();

            String sql = "Select FROM TESTE_ANDERSON WHERE cod_mer = " + cod_mer;
            

            // Executa o comando SQL
            stmt.executeUpdate(sql);
			//Fecha a conex�o
	        con.close();
            //Fecha o fluxo
            stmt.close();

        } catch (Exception ex) {
            return(false);
        }
        return(true);
    }

    public ResultSet consultar(String sql){
    	ResultSet resultado;
    	try {
            // Carregar Driver do MySQL
            Class.forName("com.mysql.jdbc.Driver");
            //Fazer a conex�o
            //Verifique se o usu�rio root e a senha root s�o iguais na m�quina de teste
            //caso contr�rio, altere na linha abaixo.
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/TESTE_ANDERSON", "root", "Als301295");
 			//Criar o fluxo para mandar comando sql o banco
            Statement stmt = con.createStatement();
            // Executa o comando SQL
            resultado = stmt.executeQuery(sql);

            return resultado;

        } catch (Exception ex) {
            return null;
        }
    }
}